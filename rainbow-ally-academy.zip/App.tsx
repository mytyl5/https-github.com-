
import React, { useState, useCallback } from 'react';
import { Difficulty, QuizResult } from './types';
import { QUIZ_DATA } from './constants';
import Header from './components/Header';
import QuizCard from './components/QuizCard';
import ResultCard from './components/ResultCard';

const App: React.FC = () => {
  const [screen, setScreen] = useState<'welcome' | 'quiz' | 'result'>('welcome');
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.BEGINNER);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [finalResult, setFinalResult] = useState<QuizResult | null>(null);

  const startQuiz = (level: Difficulty) => {
    setDifficulty(level);
    setCurrentQuestionIdx(0);
    setScore(0);
    setScreen('quiz');
  };

  const handleAnswer = (isCorrect: boolean) => {
    const newScore = isCorrect ? score + 1 : score;
    setScore(newScore);

    const nextIdx = currentQuestionIdx + 1;
    if (nextIdx < QUIZ_DATA[difficulty].length) {
      setCurrentQuestionIdx(nextIdx);
    } else {
      setFinalResult({
        score: newScore,
        total: QUIZ_DATA[difficulty].length,
        difficulty: difficulty,
        allyType: "Pending", // Set in ResultCard
        allyDescription: "",
        badgeEmoji: "🌈"
      });
      setScreen('result');
    }
  };

  const reset = useCallback(() => {
    setScreen('welcome');
    setFinalResult(null);
    setScore(0);
    setCurrentQuestionIdx(0);
  }, []);

  return (
    <div className="min-h-screen pt-20 pb-10 bg-[#fdfbfb]">
      <Header onReset={reset} />
      
      <main className="container mx-auto px-4 flex flex-col items-center justify-center">
        {screen === 'welcome' && (
          <div className="w-full max-w-2xl text-center space-y-8 animate-fadeIn">
            <div className="relative inline-block">
               <span className="text-8xl mb-4 block animate-bounce">🦄</span>
               <div className="absolute -top-4 -right-4 bg-yellow-400 text-white text-xs font-bold px-3 py-1 rounded-full rotate-12 shadow-md">
                 Let's Learn!
               </div>
            </div>
            
            <div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-800 mb-4 leading-tight">
                Rainbow <br/>
                <span className="rainbow-text">Ally Academy</span>
              </h2>
              <p className="text-gray-500 font-medium max-w-md mx-auto">
                LGBTQ+のことを楽しく学んで、世界をよりカラフルにする「アライ（味方）」への一歩を踏み出そう！
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              {[
                { level: Difficulty.BEGINNER, label: "初級", color: "from-green-400 to-emerald-500", desc: "まずはここから！" },
                { level: Difficulty.INTERMEDIATE, label: "中級", color: "from-blue-400 to-indigo-500", desc: "もっと詳しく！" },
                { level: Difficulty.ADVANCED, label: "上級", color: "from-purple-400 to-pink-500", desc: "アライのプロへ" },
              ].map((item) => (
                <button
                  key={item.level}
                  onClick={() => startQuiz(item.level)}
                  className={`relative group bg-gradient-to-br ${item.color} p-6 rounded-[2rem] text-white shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-1 active:scale-95`}
                >
                  <span className="block text-2xl font-black mb-1">{item.label}</span>
                  <span className="block text-xs font-bold opacity-80 uppercase tracking-tighter">{item.desc}</span>
                  <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity rounded-[2rem]"></div>
                </button>
              ))}
            </div>


          </div>
        )}

        {screen === 'quiz' && (
          <QuizCard
            question={QUIZ_DATA[difficulty][currentQuestionIdx]}
            questionNumber={currentQuestionIdx + 1}
            totalQuestions={QUIZ_DATA[difficulty].length}
            onAnswer={handleAnswer}
          />
        )}

        {screen === 'result' && finalResult && (
          <ResultCard 
            result={finalResult} 
            onReset={reset}
          />
        )}
      </main>

      {/* Decorative background elements */}
      <div className="fixed -bottom-24 -left-24 w-64 h-64 bg-red-100 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
      <div className="fixed -top-24 -right-24 w-64 h-64 bg-blue-100 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
    </div>
  );
};

export default App;
