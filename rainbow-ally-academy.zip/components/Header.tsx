
import React from 'react';

interface HeaderProps {
  onReset: () => void;
}

const Header: React.FC<HeaderProps> = ({ onReset }) => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md shadow-sm z-50 px-4 py-3 flex items-center justify-between">
      <div 
        className="flex items-center gap-2 cursor-pointer" 
        onClick={onReset}
      >
        <span className="text-2xl">🌈</span>
        <h1 className="text-xl font-bold rainbow-text">Ally Academy</h1>
      </div>
      <button 
        onClick={onReset}
        className="text-sm font-medium text-gray-500 hover:text-gray-800 transition-colors"
      >
        トップへ戻る
      </button>
    </header>
  );
};

export default Header;
