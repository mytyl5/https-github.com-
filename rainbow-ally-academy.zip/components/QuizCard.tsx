
import React, { useState } from 'react';
import { Question } from '../types';

interface QuizCardProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  onAnswer: (isCorrect: boolean) => void;
}

const QuizCard: React.FC<QuizCardProps> = ({ question, questionNumber, totalQuestions, onAnswer }) => {
  const [selected, setSelected] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const handleSelect = (index: number) => {
    if (selected !== null) return;
    setSelected(index);
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (selected === null) return;
    onAnswer(selected === question.correctAnswer);
    setSelected(null);
    setShowExplanation(false);
  };

  return (
    <div className="w-full max-w-lg mx-auto p-4 animate-fadeIn">
      <div className="mb-6">
        <div className="flex justify-between items-end mb-2">
          <span className="text-sm font-bold text-gray-500">QUESTION {questionNumber} / {totalQuestions}</span>
          <div className="h-2 w-32 bg-gray-200 rounded-full overflow-hidden">
             <div 
               className="h-full bg-gradient-to-r from-red-400 to-purple-500 transition-all duration-500" 
               style={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
             />
          </div>
        </div>
        <h2 className="text-xl font-bold text-gray-800 leading-relaxed min-h-[4rem]">
          {question.text}
        </h2>
      </div>

      <div className="space-y-3">
        {question.options.map((option, index) => {
          let style = "bg-white border-2 border-gray-100 hover:border-gray-200 text-gray-700";
          if (selected !== null) {
            if (index === question.correctAnswer) {
              style = "bg-green-50 border-green-500 text-green-700 ring-2 ring-green-100";
            } else if (index === selected) {
              style = "bg-red-50 border-red-500 text-red-700";
            } else {
              style = "bg-gray-50 border-gray-100 text-gray-400 opacity-60";
            }
          }

          return (
            <button
              key={index}
              disabled={selected !== null}
              onClick={() => handleSelect(index)}
              className={`w-full text-left p-4 rounded-2xl font-bold transition-all duration-300 transform active:scale-95 ${style}`}
            >
              <div className="flex items-center gap-3">
                <span className={`w-8 h-8 flex items-center justify-center rounded-full text-sm ${selected === index ? 'bg-current text-white' : 'bg-gray-100'}`}>
                  {String.fromCharCode(65 + index)}
                </span>
                {option}
              </div>
            </button>
          );
        })}
      </div>

      {showExplanation && (
        <div className="mt-8 p-6 bg-white rounded-3xl border-2 border-dashed border-rainbow-400 shadow-xl animate-bounceIn">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">{selected === question.correctAnswer ? '✨' : '📖'}</span>
            <span className={`font-bold ${selected === question.correctAnswer ? 'text-green-600' : 'text-blue-600'}`}>
              {selected === question.correctAnswer ? '正解！素晴らしい！' : '解説を見てみよう'}
            </span>
          </div>
          <p className="text-gray-700 text-sm leading-relaxed mb-4">
            {question.explanation}
          </p>
          <button
            onClick={handleNext}
            className="w-full bg-gray-900 text-white py-3 rounded-xl font-bold hover:bg-black transition-colors"
          >
            次へ進む
          </button>
        </div>
      )}
    </div>
  );
};

export default QuizCard;
