
import React, { useEffect, useState } from 'react';
import { QuizResult, AllyProfile } from '../types';
import { ALLY_PROFILES } from '../constants';
import { getAllyEncouragement } from '../geminiService';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface ResultCardProps {
  result: QuizResult;
  onReset: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, onReset }) => {
  const [encouragement, setEncouragement] = useState("ロード中...");
  
  // Find matching profile based on score
  const getProfile = (): AllyProfile => {
    const score = result.score;
    if (score >= 9) return ALLY_PROFILES[2]; // Leader
    if (score >= 7) return ALLY_PROFILES[3]; // Passionate
    if (score >= 5) return ALLY_PROFILES[1]; // Heartful
    if (score >= 3) return ALLY_PROFILES[4]; // Listener
    return ALLY_PROFILES[0]; // Beginner
  };

  const profile = getProfile();

  useEffect(() => {
    getAllyEncouragement(result.score, result.difficulty).then(setEncouragement);
  }, [result]);

  const chartData = [
    { name: 'Correct', value: result.score },
    { name: 'Incorrect', value: result.total - result.score },
  ];
  const COLORS = ['#10b981', '#f3f4f6'];

  return (
    <div className="w-full max-w-2xl mx-auto p-4 animate-scaleIn">
      <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border-8 border-white">
        <div className="rainbow-bg p-8 text-center relative overflow-hidden">
          {/* Confetti decoration */}
          <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
             {[...Array(12)].map((_, i) => (
               <span key={i} className="absolute text-2xl" style={{ 
                 top: `${Math.random()*100}%`, 
                 left: `${Math.random()*100}%`,
                 transform: `rotate(${Math.random()*360}deg)`
               }}>✨</span>
             ))}
          </div>

          <div className="relative z-10">
            <span className="inline-block px-4 py-1 bg-white/50 backdrop-blur rounded-full text-xs font-bold text-gray-600 mb-2">
              LEVEL: {result.difficulty}
            </span>
            <h2 className="text-3xl font-black text-gray-800 mb-4">
              あなたの診断結果
            </h2>
            
            <div className="flex flex-col items-center justify-center mb-6">
              <div className="w-48 h-48 relative">
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        startAngle={90}
                        endAngle={-270}
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                 </ResponsiveContainer>
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-4xl font-black text-gray-800">{result.score}</span>
                    <span className="text-xs font-bold text-gray-400">/ {result.total}</span>
                 </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-lg mb-6">
              <div className="text-6xl mb-4 transform hover:scale-110 transition-transform cursor-default">
                {profile.icon}
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${profile.color}`}>
                {profile.name}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {profile.description}
              </p>
            </div>

            <div className="bg-white/40 backdrop-blur-md rounded-2xl p-4 border border-white/50">
              <p className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-1">Character Message</p>
              <p className="text-gray-800 font-bold italic">「{encouragement}」</p>
            </div>
          </div>
        </div>

        <div className="p-8 text-center bg-gray-50">
          <div className="mb-8">
            <h4 className="text-sm font-bold text-gray-500 mb-4">🎁 ブースのスタッフに見せてね！</h4>
            <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-gray-300 inline-block rotate-1">
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <p className="text-xs font-bold text-gray-400">SPECIAL REWARD</p>
                  <p className="text-lg font-black rainbow-text">アライグッズ引換証</p>
                </div>
                <div className="text-4xl">🎟️</div>
              </div>
            </div>
          </div>

          <button
            onClick={onReset}
            className="w-full max-w-xs mx-auto bg-gray-900 text-white py-4 rounded-2xl font-bold hover:bg-black transform active:scale-95 transition-all shadow-xl"
          >
            もう一度挑戦する
          </button>
          <p className="mt-4 text-[10px] text-gray-400">
            ※グッズの在庫には限りがあります。
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
