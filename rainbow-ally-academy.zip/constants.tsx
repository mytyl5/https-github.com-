
import { Difficulty, Question, AllyProfile } from './types';

export const QUIZ_DATA: Record<Difficulty, Question[]> = {
  [Difficulty.BEGINNER]: [
    {
      id: 1,
      text: "LGBTQのシンボルとしてよく使われる「6色の旗」は何と呼ばれていますか？",
      options: ["カラフルフラッグ", "レインボーフラッグ", "ピースフラッグ", "ミラクルフラッグ"],
      correctAnswer: 1,
      explanation: "正解はレインボーフラッグ！1978年にギルバート・ベイカーによってデザインされ、多様性の象徴となりました。"
    },
    {
      id: 2,
      text: "LGBTQの「L」は何を指していますか？",
      options: ["レズビアン", "ライオン", "ラベンダー", "リーダーシップ"],
      correctAnswer: 0,
      explanation: "Lはレズビアン（女性の同性愛者）の頭文字です。"
    },
    {
      id: 3,
      text: "自分自身の性別をどのように認識しているかを何と言いますか？",
      options: ["性自認", "性的指向", "性別発表", "心の住所"],
      correctAnswer: 0,
      explanation: "自分が自分の性をどう思っているかを「性自認（ジェンダー・アイデンティティ）」と言います。"
    },
    {
      id: 4,
      text: "誰を好きになるか（またはならないか）を何と言いますか？",
      options: ["趣味嗜好", "性的指向", "未来予想", "自己肯定"],
      correctAnswer: 1,
      explanation: "どの性に惹かれるかを「性的指向（セクシュアル・オリエンテーション）」と言います。"
    },
    {
      id: 5,
      text: "LGBTQを支援し、連帯する人を何と呼びますか？",
      options: ["フレンド", "サポーター", "アライ（Ally）", "パートナー"],
      correctAnswer: 2,
      explanation: "アライは英語で「同盟、味方」という意味。LGBTQ当事者ではないけれど、力になりたい人を指します。"
    },
    {
      id: 6,
      text: "レインボーフラッグの「赤」が表す意味は何でしょう？",
      options: ["愛", "情熱", "生命", "平和"],
      correctAnswer: 2,
      explanation: "赤は「生命（Life）」、橙は「癒やし」、黄は「太陽」、緑は「自然」、青は「調和」、紫は「精神」を象徴しています。"
    },
    {
      id: 7,
      text: "トランスジェンダーの人が、本来の性で過ごすことを支援する日はいつ？",
      options: ["1月1日", "3月31日", "10月31日", "12月25日"],
      correctAnswer: 1,
      explanation: "3月31日は「国際トランスジェンダー可視化の日」です。"
    },
    {
      id: 8,
      text: "「LGBTQ+」の「+」にはどんな意味が込められていますか？",
      options: ["プラスアルファ", "それ以外の多様な性", "足し算", "もっと上を目指す"],
      correctAnswer: 1,
      explanation: "LGBTQ以外にもたくさんのセクシュアリティがあり、全てを包含するという意味が込められています。"
    },
    {
      id: 9,
      text: "カミングアウト（公表）を受けた時、一番大切な態度は？",
      options: ["驚いて逃げる", "否定する", "話を否定せず聴く", "勝手に他人に話す"],
      correctAnswer: 2,
      explanation: "信頼して話してくれたことを受け止め、まずは「話してくれてありがとう」と伝えるのが大切です。"
    },
    {
      id: 10,
      text: "日本各地で開催されている、多様性を祝うイベントの名前は？",
      options: ["レインボーフェス", "プライドパレード", "ハッピーパレード", "カラーフル・デイ"],
      correctAnswer: 1,
      explanation: "プライド（誇り）を持って歩く「プライドパレード」は世界中で行われています。"
    }
  ],
  [Difficulty.INTERMEDIATE]: [
    // Placeholder for other levels
    { id: 1, text: "SOGI（ソジ）の「G」は何の略？", options: ["Gender Identity", "Generous", "General", "Genial"], correctAnswer: 0, explanation: "GはGender Identity（性自認）です。SOGIは性的指向と性自認の総称です。" },
    { id: 2, text: "カミングアウトの反対で、本人の許可なくセクシュアリティを曝露することを何と言う？", options: ["インティング", "アウティング", "リーク", "バイラル"], correctAnswer: 1, explanation: "アウティングは重大なプライバシー侵害であり、絶対にしてはいけません。" },
    { id: 3, text: "誰に対しても恋愛感情や性的欲求を抱かない人を何と言う？", options: ["バイセクシュアル", "アセクシュアル", "パンセクシュアル", "クィア"], correctAnswer: 1, explanation: "Asexual（アセクシュアル）は、無性愛者とも呼ばれます。" },
    { id: 4, text: "「クィア」という言葉の元々の意味は？", options: ["素敵な", "変な・風変わりな", "勇気ある", "虹色の"], correctAnswer: 1, explanation: "元々は蔑称でしたが、現在はポジティブな意味で使われるようになっています。" },
    { id: 5, text: "性的指向が、特定の性別に限らず「全ての人」に向く人を何と言う？", options: ["バイセクシュアル", "パンセクシュアル", "ヘテロセクシュアル", "ホモセクシュアル"], correctAnswer: 1, explanation: "Pansexual（パンセクシュアル）は、全性愛とも呼ばれます。" },
    { id: 6, text: "生まれた時の性別と、自分の性自認が一致している人を何と言う？", options: ["トランスジェンダー", "シスジェンダー", "ノーマルジェンダー", "リアルジェンダー"], correctAnswer: 1, explanation: "Cisgender（シスジェンダー）は、トランスジェンダーの対義語です。" },
    { id: 7, text: "職場のLGBTQへの取り組みを評価する指標の名前は？", options: ["RAINBOW Index", "PRIDE Index", "D&I Score", "Ally Rank"], correctAnswer: 1, explanation: "Work with Prideが策定した「PRIDE指標」が有名です。" },
    { id: 8, text: "同性婚を認めていない国に対して、人権の観点から勧告を行う国際機関は？", options: ["WHO", "国連（UN）", "FIFA", "IOC"], correctAnswer: 1, explanation: "国連は性的指向や性自認に基づく差別をなくすよう求めています。" },
    { id: 9, text: "アライとして最初にできるアクションは何？", options: ["旗を掲げる", "寄付する", "正しく知る", "デモに参加する"], correctAnswer: 2, explanation: "まずは正しい知識を身につけることが、理解の第一歩です。" },
    { id: 10, text: "日本の自治体で導入が広がっている、同性カップルを認める制度は？", options: ["パートナーシップ制度", "同性婚特区", "家族認定証", "フレンドシップ制度"], correctAnswer: 0, explanation: "法的効力は限定的ですが、多くの自治体で導入されています。" }
  ],
  [Difficulty.ADVANCED]: [
    { id: 1, text: "「ストーンウォールの反乱」が起きたのは西暦何年？", options: ["1959年", "1969年", "1979年", "1989年"], correctAnswer: 1, explanation: "1969年、ニューヨークのバー「ストーンウォール・イン」での反乱が近代LGBTQ運動の起点と言われます。" },
    { id: 2, text: "現在、同性婚が法律で認められている国は約いくつ？（2024年現在）", options: ["約10ヶ国", "約35ヶ国", "約70ヶ国", "約100ヶ国"], correctAnswer: 1, explanation: "世界で約35以上の国と地域で同性婚が認められています。" },
    { id: 3, text: "日本で初めてパートナーシップ制度を導入した自治体はどこ？（2つ）", options: ["新宿区・港区", "渋谷区・世田谷区", "中野区・杉並区", "横浜市・大阪市"], correctAnswer: 1, explanation: "2015年に渋谷区と世田谷区が同時に開始しました。" },
    { id: 4, text: "性同一性障害特例法で、戸籍変更の要件となっていた「生殖不能要件」に対する最高裁の判断は？（2023年）", options: ["合憲", "違憲", "判断回避", "一部合憲"], correctAnswer: 1, explanation: "2023年、最高裁は手術を必要とする要件を「違憲」と判断しました。" },
    { id: 5, text: "アライの行動として「無意識の偏見」に気づくことを何と言う？", options: ["マイクロアグレッションの解消", "アンコンシャス・バイアスの自覚", "アサーティブ・コミュニケーション", "エンパワーメント"], correctAnswer: 1, explanation: "自分の中にある無意識の思い込みに気づくことは非常に重要です。" },
    { id: 6, text: "「インターセクショナリティ」という概念が説明するのは？", options: ["交差する虹", "差別やアイデンティティの重なり", "国際的な協力", "多角的な経営"], correctAnswer: 1, explanation: "人種、性、階級など、複数の属性が重なり合うことで生じる特有の抑圧を理解する概念です。" },
    { id: 7, text: "職場でのSOGIハラを防止することが義務付けられた法律は？", options: ["労働基準法", "パワハラ防止法（労働施策総合推進法）", "男女雇用機会均等法", "個人情報保護法"], correctAnswer: 1, explanation: "2020年（中小企業は2022年）から義務化されています。" },
    { id: 8, text: "「アライ・シップ」の「シップ」とは何を指す？", options: ["船", "状態やスキル・姿勢", "指導力", "仲間意識"], correctAnswer: 1, explanation: "名詞に付く「-ship」は性質や状態、技能を表します（Friendship, Leadershipなど）。" },
    { id: 9, text: "G7諸国の中で、同性婚も法的保護（パートナーシップ含む）も国レベルで存在しない国は？", options: ["イタリア", "フランス", "日本", "アメリカ"], correctAnswer: 2, explanation: "日本はG7の中で唯一、国レベルでの法的保護が確立されていません。" },
    { id: 10, text: "企業がLGBTQ施策を推進することで得られる経済的メリットの総称は？", options: ["ピンク・ドル", "レインボー・エコノミー", "ダイバーシティ・マネジメント", "クィア・キャピタル"], correctAnswer: 0, explanation: "LGBTQ市場の購買力は「ピンク・ドル」と呼ばれ、非常に大きな影響力を持ちます。" }
  ]
};

export const ALLY_PROFILES: AllyProfile[] = [
  { name: "レインボー・ビギナー", description: "まずは知ることから。優しさと好奇心にあふれた、未来のアライ候補！", icon: "🌱", color: "text-green-500" },
  { name: "ハートフル・サポーター", description: "誰かの力になりたいという温かい心を持っています。身近なところから変化を作れる人です。", icon: "💖", color: "text-red-400" },
  { name: "インクルーシブ・リーダー", description: "知識も行動力も抜群！周りを巻き込んで、みんなが過ごしやすい場所を作れるリーダータイプです。", icon: "👑", color: "text-yellow-500" },
  { name: "情熱のレインボー・アライ", description: "当事者の声に耳を傾け、社会を変えるために情熱を燃やす、頼もしいアライです！", icon: "🌈", color: "text-blue-500" },
  { name: "静かなる共感者", description: "派手な行動はなくても、いつも隣でそっと寄り添い、理解を示してくれる大切な存在です。", icon: "🕊️", color: "text-purple-400" }
];
