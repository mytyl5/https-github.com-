
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const getAllyEncouragement = async (score: number, difficulty: string) => {
  const ai = getAIClient();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `あなたはLGBTQイベントのブース担当キャラクターです。
      クイズのレベル「${difficulty}」で10問中「${score}問」正解した参加者に、
      これからのアライ（支援者）としての活動を応援する、短くて温かい一言メッセージを送ってください。
      語尾は「〜だよ！」「〜だね！」など、親しみやすく可愛らしい口調でお願いします。
      20文字程度で。`,
    });
    return response.text?.trim() || "君の優しさが世界を彩るよ！";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "クイズに挑戦してくれてありがとう！";
  }
};
