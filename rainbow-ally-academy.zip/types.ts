
export enum Difficulty {
  BEGINNER = 'BEGINNER',
  INTERMEDIATE = 'INTERMEDIATE',
  ADVANCED = 'ADVANCED'
}

export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizResult {
  score: number;
  total: number;
  difficulty: Difficulty;
  allyType: string;
  allyDescription: string;
  badgeEmoji: string;
}

export interface AllyProfile {
  name: string;
  description: string;
  icon: string;
  color: string;
}
